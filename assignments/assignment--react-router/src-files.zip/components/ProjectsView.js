import React, { Component } from 'react';
import Header from './Header.js'

class ProjectsView extends Component {
  render() {
    return (
      <div className="portfolio-content">
        <Header headerTitle="Projects"/>
      </div>
    )
  }
}

export default ProjectsView
