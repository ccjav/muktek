import React, { Component } from 'react';
import Header from './Header.js'

class CvView extends Component {
  render() {
    return (
      <div className="portfolio-content">
        <Header headerTitle="C.V."/>
      </div>
    )
  }
}

export default CvView
