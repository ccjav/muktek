import React, { Component } from 'react';
import Header from './Header.js'

class HomeView extends Component {
  render() {
    return (
      <div className="portfolio-content">
        <Header headerTitle="Portfolio"/>
      </div>
    )
  }
}

export default HomeView
