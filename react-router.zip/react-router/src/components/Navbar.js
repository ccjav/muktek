import React, { Component } from "react";
import { NavLink } from "react-router-dom";

class Navbar extends Component {
  render() {
    return (
      <nav className="nav">
        NavBar
        <NavLink
          exact
          className="nav__option"
          activeClassName="nav__option--selected"
          to="/"
        >
          Home
        </NavLink>
        <NavLink
          className="nav__option"
          activeClassName="nav__option--selected"
          to="/pricing"
        >
          Pricing
        </NavLink>
        <NavLink
          className="nav__option"
          activeClassName="nav__option--selected"
          to="/dashboard"
        >
          Dashboard
        </NavLink>
        {this.props.loggedIn ? (
          <button onClick={this.props.logOut}>Log out</button>
        ) : (
          <button onClick={this.props.logIn}>Log in</button>
        )}
      </nav>
    );
  }
}

export default Navbar;
