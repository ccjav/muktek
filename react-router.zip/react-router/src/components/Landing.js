import React, { Component } from "react";
import { Link } from "react-router-dom";

import analyticsImg1 from "../images/analytics-1.png";
import analyticsImg2 from "../images/analytics-2.png";
import analyticsImg3 from "../images/analytics-3.png";

import Header from "./Header.js";

class Landing extends Component {
  render() {
    return (
      <div className="landing">
        <Header view="landing" />
        <div className="pricing-section">
          <Link to="/pricing" className="btn btn-pricing">
            Check Out Pricing
          </Link>
        </div>
        <div className="analytics">
          <img src={analyticsImg1} />
          <img src={analyticsImg2} />
          <img src={analyticsImg3} />
        </div>

        <div>
          <h2>Meet our team</h2>
          <div>
            <Link to="/users/richard">
              <img
                src="https://muktek.com/images/react-richard.jpg"
                alt="Foto de Richard"
                width={200}
                height={200}
              />
              Richard - Front-End Engineer
            </Link>
          </div>

          <div>
            <Link to="/users/comunidad">
              <img
                src="https://muktek.com/images/react-community.jpg"
                alt="Foto de la comunidad"
                width={200}
                height={200}
              />
              Comunidad MUKTEK
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default Landing;
