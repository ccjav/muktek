import React, { Component } from "react";

class UserInfo extends Component {
  render() {
    // const username = "@sparragus";
    const username = this.props.match.params.userId;

    return (
      <div className="userinfo">
        <h3>Showing Information for {username}</h3>
        <img src={`https://flathash.com/${username}`} />
      </div>
    );
  }
}

export default UserInfo;
