import React, { Component } from "react";
import { Route, Switch } from "react-router-dom";

import Navbar from "./components/Navbar";
import Landing from "./components/Landing";
import Pricing from "./components/Pricing";
import Dashboard from "./components/Dashboard.js";
import UserInfo from "./components/UserInfo.js";
import NoMatch from "./components/NoMatch";

class App extends Component {
  state = {
    loggedIn: false
  };

  handleLogOut = () => {
    this.setState({
      loggedIn: false
    });
  };

  handleLogIn = () => {
    this.setState({
      loggedIn: true
    });
  };

  render() {
    return (
      <div className="App">
        <Navbar
          loggedIn={this.state.loggedIn}
          logIn={this.handleLogIn}
          logOut={this.handleLogOut}
        />

        <Switch>
          <Route exact path="/" component={Landing} />
          <Route
            exact
            path="/pricing"
            component={props => {
              return <Pricing discount={20} {...props} />;
            }}
          />
          <Route
            exact
            path="/dashboard"
            component={props => {
              return <Dashboard loggedIn={this.state.loggedIn} {...props} />;
            }}
          />
          <Route exact path="/users/:userId" component={UserInfo} />
          <Route component={NoMatch} />
        </Switch>
      </div>
    );
  }
}

export default App;

// Estos dos componentes son iguales: uno es una función, otro es una clase

// function UserInfo(props) {
//   return <h1>{props.match.params.userId}</h1>;
// }

// class UserInfo extends Component {
//   render() {
//     return <h1>{this.props.match.params.userId}</h1>;
//   }
// }
